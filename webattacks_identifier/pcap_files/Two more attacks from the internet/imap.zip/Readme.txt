Source:
https://asecuritysite.com/forensics/pcap?infile=imap.pcap